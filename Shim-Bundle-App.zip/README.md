# Shim Bundle App

## Description
The Shim Bundle App is a simple web application for managing shim bundle data. It allows users to:
- Save the weight and count of shim bundles.
- Undo the last action.
- Print the saved data.
- View help instructions on how to use the application.

## Features
- **Save Data**: Saves the shim bundle's weight and count along with a timestamp to local storage.
- **Undo Action**: Allows users to undo the last entered shim bundle data.
- **Print Data**: Allows users to print all saved shim bundle data.
- **Help Modal**: Provides instructions on how to use the app.

## How to Use
1. **Save Shim Bundle**: Enter the weight and count of the shim bundle, then click the "Save" button to store the data.
2. **Undo Last Action**: If you've made a mistake, you can click the "Undo" button to revert to the previous state.
3. **Print Data**: To print the saved shim data, click the "Print" button.
4. **Get Help**: Click the "Help" button to view instructions on how to use the app.

## Requirements
- A modern web browser (Chrome, Firefox, Safari, etc.)
- JavaScript enabled in the browser

## Installation
To run this application locally:
1. Download or clone this repository.
2. Open the `index.html` file in your web browser.

## Technologies Used
- HTML
- CSS (optional, if you style the app further)
- JavaScript

## License
This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## Contact
If you have any questions or suggestions, feel free to reach out via email: [your-email@example.com].

